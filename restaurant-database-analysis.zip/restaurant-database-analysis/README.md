# 🍽️ Restaurant Database Analysis (SQL)

Exploratory data analysis of a restaurant's sales database using **advanced SQL**: joins, CTEs, window functions, and subqueries, to produce KPI reports on revenue trends, menu performance, customer behaviour, and peak operating hours.

> **Note:** The dataset is **synthetic** (generated with `generate_data.py`, seed 42) so the project is fully reproducible. The SQL logic applies to any real restaurant POS data with the same structure.

## 📊 Dataset
| Table | Rows | Description |
|---|---|---|
| `customers` | 1,500 | Customer name, city, signup date |
| `menu_items` | 20 | Item, category, price |
| `orders` | **12,500** | Order date, hour, day, order type, payment method |
| `order_items` | 27,695 | Line items (item + quantity) per order |

Period: Jan–Dec 2024.

**Schema:** `customers (1) ─── (M) orders (1) ─── (M) order_items (M) ─── (1) menu_items`

## 🛠️ Tools & SQL concepts
SQL (MySQL 8 / PostgreSQL / SQLite compatible) · Python (data generation only)
- **Joins:** INNER, LEFT, self-join (market-basket pairs)
- **CTEs:** multi-step logic for readable queries
- **Window functions:** `LAG`, `RANK`, `DENSE_RANK`, `NTILE`, running `SUM() OVER`, moving `AVG()` with frame clause
- **Subqueries:** correlated and scalar
- **Data quality checks:** NULLs, duplicates, orphan records

## 📁 Project structure
```
restaurant-database-analysis/
├── README.md
├── schema.sql                  # table definitions, PK/FK, constraints
├── generate_data.py            # creates the CSV dataset
├── build_db.py                 # builds restaurant.db (SQLite) from CSVs
├── restaurant.db               # ready-to-query database
├── data/                       # CSV files
└── queries/
    ├── 01_data_quality_checks.sql
    ├── 02_revenue_kpis.sql
    ├── 03_menu_performance.sql
    ├── 04_customer_analysis.sql
    └── 05_operations_patterns.sql
```

## ▶️ How to run
**Option A: SQLite (quickest)**
```bash
python build_db.py
sqlite3 restaurant.db < queries/02_revenue_kpis.sql
```
Or open `restaurant.db` in [DB Browser for SQLite](https://sqlitebrowser.org/) and paste any query.

**Option B: MySQL**
1. Run `schema.sql`
2. Import the CSVs from `data/` (Workbench → *Table Data Import Wizard*)
3. Run the files in `queries/`

*(In MySQL, replace `SUBSTR(order_date,1,7)` with `DATE_FORMAT(order_date,'%Y-%m')` if you prefer.)*

## 🔍 Key insights
| KPI | Result |
|---|---|
| Total revenue | **₹75.4 lakh** (₹7,536,280) |
| Total orders | 12,500 |
| Average order value | **₹602.90** |

- **Growth:** Revenue grew from ₹4.6L in January to ₹8.3L in December (~81% increase), with a festive-season lift in Oct–Dec.
- **Menu:** *Mains* generate **50%** of revenue. *Butter Chicken*, *Paneer Tikka Pizza*, and *Chicken Biryani* are the top three items.
- **Customers:** The top 20% of customers drive **~55%** of revenue (Pareto effect); ~15% of customers are "Loyal" (16+ orders).
- **Peak times:** Two clear rushes: **lunch (1 PM)** and **dinner (7–8 PM)**. **Friday–Sunday** each carry ~60% more orders than weekdays.
- **Geography:** Bangalore contributes the majority of orders (~60%).

## 💡 Recommendations
1. Staff up for 12–2 PM and 7–9 PM, and for Fri–Sun.
2. Run a loyalty programme for the top-quintile customers who drive over half of revenue.
3. Bundle high-frequency pairs (found via self-join) as combo offers.
4. Run weekday lunch promotions to lift the slower Mon–Thu days.

## 👩‍💻 Author
**Kavyashree Shiny S**: Data Analyst · [LinkedIn](https://linkedin.com/in/kavyashreeshiny)
