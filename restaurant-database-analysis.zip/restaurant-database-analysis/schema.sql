-- Restaurant Database Analysis: schema (works in MySQL 8+, PostgreSQL, SQLite)
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS menu_items;
DROP TABLE IF EXISTS customers;

CREATE TABLE customers (
    customer_id  INT PRIMARY KEY,
    name         VARCHAR(100) NOT NULL,
    city         VARCHAR(50),
    signup_date  DATE
);

CREATE TABLE menu_items (
    item_id    INT PRIMARY KEY,
    item_name  VARCHAR(100) NOT NULL,
    category   VARCHAR(50)  NOT NULL,
    price      DECIMAL(8,2) NOT NULL CHECK (price > 0)
);

CREATE TABLE orders (
    order_id        INT PRIMARY KEY,
    customer_id     INT NOT NULL,
    order_date      DATE NOT NULL,
    order_hour      INT  NOT NULL CHECK (order_hour BETWEEN 0 AND 23),
    day_name        VARCHAR(10),
    order_type      VARCHAR(20),
    payment_method  VARCHAR(20),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE order_items (
    order_item_id  INT PRIMARY KEY,
    order_id       INT NOT NULL,
    item_id        INT NOT NULL,
    quantity       INT NOT NULL CHECK (quantity > 0),
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (item_id)  REFERENCES menu_items(item_id)
);

CREATE INDEX idx_orders_date ON orders(order_date);
CREATE INDEX idx_items_order ON order_items(order_id);
