"""Builds restaurant.db (SQLite) from schema.sql + CSVs.
Run: python build_db.py   then open restaurant.db in DB Browser for SQLite.
"""
import sqlite3, csv, os
if os.path.exists("restaurant.db"): os.remove("restaurant.db")
con = sqlite3.connect("restaurant.db")
con.executescript(open("schema.sql").read())
for t in ["customers", "menu_items", "orders", "order_items"]:
    rows = list(csv.reader(open(f"data/{t}.csv")))
    con.executemany(f"INSERT INTO {t} VALUES ({','.join('?'*len(rows[0]))})", rows[1:])
con.commit()
print("restaurant.db created")
