-- 01. DATA QUALITY CHECKS (run before any analysis)

-- Row counts per table
SELECT 'customers' AS tbl, COUNT(*) AS rows_count FROM customers
UNION ALL SELECT 'menu_items', COUNT(*) FROM menu_items
UNION ALL SELECT 'orders', COUNT(*) FROM orders
UNION ALL SELECT 'order_items', COUNT(*) FROM order_items;

-- Orders with no line items (should be 0)
SELECT COUNT(*) AS orders_without_items
FROM orders o
LEFT JOIN order_items oi ON o.order_id = oi.order_id
WHERE oi.order_id IS NULL;

-- Duplicate order_item rows for the same order + item (should be 0)
SELECT order_id, item_id, COUNT(*) AS dup_count
FROM order_items
GROUP BY order_id, item_id
HAVING COUNT(*) > 1;

-- NULL checks on key columns
SELECT
    SUM(CASE WHEN customer_id    IS NULL THEN 1 ELSE 0 END) AS null_customer,
    SUM(CASE WHEN order_date     IS NULL THEN 1 ELSE 0 END) AS null_date,
    SUM(CASE WHEN payment_method IS NULL THEN 1 ELSE 0 END) AS null_payment
FROM orders;
