-- 04. CUSTOMER ANALYSIS

-- Top 10 customers by lifetime spend
WITH customer_spend AS (
    SELECT c.customer_id, c.name, c.city,
           COUNT(DISTINCT o.order_id)  AS orders_placed,
           SUM(oi.quantity * m.price)  AS total_spent
    FROM customers c
    JOIN orders o       ON c.customer_id = o.customer_id
    JOIN order_items oi ON o.order_id    = oi.order_id
    JOIN menu_items m   ON oi.item_id    = m.item_id
    GROUP BY c.customer_id, c.name, c.city
)
SELECT customer_id, name, city, orders_placed, total_spent,
       DENSE_RANK() OVER (ORDER BY total_spent DESC) AS spend_rank
FROM customer_spend
ORDER BY spend_rank
LIMIT 10;

-- Customer segmentation: one-time vs repeat vs loyal (CTE + CASE)
WITH order_counts AS (
    SELECT customer_id, COUNT(*) AS n_orders
    FROM orders
    GROUP BY customer_id
)
SELECT CASE WHEN n_orders = 1  THEN '1. One-time'
            WHEN n_orders <= 5 THEN '2. Occasional (2-5)'
            WHEN n_orders <= 15 THEN '3. Regular (6-15)'
            ELSE '4. Loyal (16+)' END AS segment,
       COUNT(*) AS customers,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct_customers
FROM order_counts
GROUP BY segment
ORDER BY segment;

-- Revenue contribution of top 20% customers (Pareto check, NTILE)
WITH spend AS (
    SELECT o.customer_id, SUM(oi.quantity * m.price) AS total_spent
    FROM orders o
    JOIN order_items oi ON o.order_id = oi.order_id
    JOIN menu_items m   ON oi.item_id = m.item_id
    GROUP BY o.customer_id
),
buckets AS (
    SELECT *, NTILE(5) OVER (ORDER BY total_spent DESC) AS quintile FROM spend
)
SELECT quintile,
       COUNT(*) AS customers,
       SUM(total_spent) AS revenue,
       ROUND(100.0 * SUM(total_spent) / SUM(SUM(total_spent)) OVER (), 1) AS pct_revenue
FROM buckets
GROUP BY quintile
ORDER BY quintile;

-- Subquery: customers who spent more than the average customer
SELECT customer_id, total_spent
FROM (
    SELECT o.customer_id, SUM(oi.quantity * m.price) AS total_spent
    FROM orders o
    JOIN order_items oi ON o.order_id = oi.order_id
    JOIN menu_items m   ON oi.item_id = m.item_id
    GROUP BY o.customer_id
) t
WHERE total_spent > (SELECT AVG(total_spent) FROM (
        SELECT SUM(oi.quantity * m.price) AS total_spent
        FROM orders o
        JOIN order_items oi ON o.order_id = oi.order_id
        JOIN menu_items m   ON oi.item_id = m.item_id
        GROUP BY o.customer_id) x)
ORDER BY total_spent DESC
LIMIT 10;
