-- 05. OPERATIONS: PEAK TIMES, ORDER TYPE, PAYMENT MIX

-- Orders and revenue by hour of day
SELECT o.order_hour,
       COUNT(DISTINCT o.order_id)  AS orders,
       SUM(oi.quantity * m.price)  AS revenue
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
JOIN menu_items m   ON oi.item_id = m.item_id
GROUP BY o.order_hour
ORDER BY orders DESC;

-- Busiest day of week, ranked
WITH daily AS (
    SELECT o.day_name, COUNT(DISTINCT o.order_id) AS orders,
           SUM(oi.quantity * m.price) AS revenue
    FROM orders o
    JOIN order_items oi ON o.order_id = oi.order_id
    JOIN menu_items m   ON oi.item_id = m.item_id
    GROUP BY o.day_name
)
SELECT day_name, orders, revenue,
       RANK() OVER (ORDER BY orders DESC) AS busiest_rank
FROM daily;

-- Average order value by order type and payment method
WITH order_totals AS (
    SELECT o.order_id, o.order_type, o.payment_method,
           SUM(oi.quantity * m.price) AS order_value
    FROM orders o
    JOIN order_items oi ON o.order_id = oi.order_id
    JOIN menu_items m   ON oi.item_id = m.item_id
    GROUP BY o.order_id, o.order_type, o.payment_method
)
SELECT order_type, payment_method,
       COUNT(*) AS orders,
       ROUND(AVG(order_value), 2) AS avg_order_value
FROM order_totals
GROUP BY order_type, payment_method
ORDER BY order_type, avg_order_value DESC;

-- Revenue by customer city
SELECT c.city, COUNT(DISTINCT o.order_id) AS orders,
       SUM(oi.quantity * m.price) AS revenue
FROM customers c
JOIN orders o       ON c.customer_id = o.customer_id
JOIN order_items oi ON o.order_id    = oi.order_id
JOIN menu_items m   ON oi.item_id    = m.item_id
GROUP BY c.city
ORDER BY revenue DESC;
