-- 02. HEADLINE KPIs and MONTHLY REVENUE TREND

-- Overall KPIs: total revenue, orders, average order value (AOV)
WITH order_totals AS (
    SELECT o.order_id,
           SUM(oi.quantity * m.price) AS order_value
    FROM orders o
    JOIN order_items oi ON o.order_id = oi.order_id
    JOIN menu_items  m  ON oi.item_id = m.item_id
    GROUP BY o.order_id
)
SELECT ROUND(SUM(order_value), 0)  AS total_revenue,
       COUNT(*)                    AS total_orders,
       ROUND(AVG(order_value), 2)  AS avg_order_value
FROM order_totals;

-- Monthly revenue with month-over-month growth % (CTE + LAG window function)
WITH monthly AS (
    SELECT SUBSTR(o.order_date, 1, 7) AS month,
           SUM(oi.quantity * m.price) AS revenue
    FROM orders o
    JOIN order_items oi ON o.order_id = oi.order_id
    JOIN menu_items  m  ON oi.item_id = m.item_id
    GROUP BY SUBSTR(o.order_date, 1, 7)
)
SELECT month,
       revenue,
       LAG(revenue) OVER (ORDER BY month) AS prev_month_revenue,
       ROUND(100.0 * (revenue - LAG(revenue) OVER (ORDER BY month))
             / LAG(revenue) OVER (ORDER BY month), 1) AS mom_growth_pct
FROM monthly
ORDER BY month;

-- Running (cumulative) revenue and 3-month moving average
WITH monthly AS (
    SELECT SUBSTR(o.order_date, 1, 7) AS month,
           SUM(oi.quantity * m.price) AS revenue
    FROM orders o
    JOIN order_items oi ON o.order_id = oi.order_id
    JOIN menu_items  m  ON oi.item_id = m.item_id
    GROUP BY SUBSTR(o.order_date, 1, 7)
)
SELECT month,
       revenue,
       SUM(revenue) OVER (ORDER BY month) AS cumulative_revenue,
       ROUND(AVG(revenue) OVER (ORDER BY month
             ROWS BETWEEN 2 PRECEDING AND CURRENT ROW), 0) AS moving_avg_3m
FROM monthly
ORDER BY month;
