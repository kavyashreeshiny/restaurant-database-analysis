-- 03. MENU PERFORMANCE

-- Top 5 items per category by revenue (RANK window function, partitioned)
WITH item_sales AS (
    SELECT m.category, m.item_name,
           SUM(oi.quantity)            AS units_sold,
           SUM(oi.quantity * m.price)  AS revenue
    FROM order_items oi
    JOIN menu_items m ON oi.item_id = m.item_id
    GROUP BY m.category, m.item_name
),
ranked AS (
    SELECT *,
           RANK() OVER (PARTITION BY category ORDER BY revenue DESC) AS rank_in_category
    FROM item_sales
)
SELECT category, item_name, units_sold, revenue, rank_in_category
FROM ranked
WHERE rank_in_category <= 5
ORDER BY category, rank_in_category;

-- Category share of total revenue (window SUM over all rows)
WITH cat AS (
    SELECT m.category, SUM(oi.quantity * m.price) AS revenue
    FROM order_items oi
    JOIN menu_items m ON oi.item_id = m.item_id
    GROUP BY m.category
)
SELECT category, revenue,
       ROUND(100.0 * revenue / SUM(revenue) OVER (), 1) AS pct_of_total
FROM cat
ORDER BY revenue DESC;

-- Subquery: items priced above their category's average price
SELECT item_name, category, price
FROM menu_items m
WHERE price > (SELECT AVG(price) FROM menu_items WHERE category = m.category)
ORDER BY category, price DESC;

-- Items that are frequently ordered together (self-join on order_items)
SELECT a.item_id AS item_a, b.item_id AS item_b, COUNT(*) AS times_together
FROM order_items a
JOIN order_items b ON a.order_id = b.order_id AND a.item_id < b.item_id
GROUP BY a.item_id, b.item_id
ORDER BY times_together DESC
LIMIT 10;
