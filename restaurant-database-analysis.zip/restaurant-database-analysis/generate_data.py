"""Generates a synthetic restaurant dataset (12,500 orders) as CSV files.
Run: python generate_data.py
"""
import csv, random
from datetime import date, timedelta

random.seed(42)

MENU = [
 ("Margherita Pizza","Mains",320),("Paneer Tikka Pizza","Mains",380),("Chicken Biryani","Mains",350),
 ("Veg Biryani","Mains",280),("Butter Chicken","Mains",390),("Dal Makhani","Mains",260),
 ("Grilled Sandwich","Snacks",150),("French Fries","Snacks",120),("Chicken Wings","Snacks",260),
 ("Spring Rolls","Starters",180),("Paneer Tikka","Starters",240),("Tomato Soup","Starters",110),
 ("Chocolate Brownie","Desserts",140),("Gulab Jamun","Desserts",90),("Ice Cream Sundae","Desserts",160),
 ("Cold Coffee","Beverages",130),("Masala Chai","Beverages",50),("Fresh Lime Soda","Beverages",80),
 ("Mango Lassi","Beverages",110),("Mojito","Beverages",150),
]
WEIGHTS = [10,6,12,7,9,5,6,8,5,5,6,4,5,4,4,8,9,6,5,5]
CITIES = ["Bangalore","Mysore","Mangalore","Hubli","Belgaum"]
CITY_W = [60,15,10,8,7]
FIRST = ["Aarav","Priya","Rohan","Ananya","Karthik","Meera","Vikram","Sneha","Arjun","Divya","Rahul","Pooja","Suresh","Lakshmi","Nikhil","Isha","Manoj","Kavya","Deepak","Shreya"]
LAST = ["Sharma","Reddy","Nair","Gowda","Iyer","Patel","Rao","Kumar","Shetty","Hegde"]
PAY = ["UPI","Card","Cash"]; PAY_W=[50,30,20]
OTYPE = ["Dine-in","Takeaway","Delivery"]; OTYPE_W=[50,20,30]
HOURS = list(range(11,23))
HOUR_W = [4,10,14,8,4,3,4,7,12,14,9,3]   # lunch + dinner peaks

start, end = date(2024,1,1), date(2024,12,31)
days = (end-start).days+1

with open("data/customers.csv","w",newline="") as f:
    w=csv.writer(f); w.writerow(["customer_id","name","city","signup_date"])
    for i in range(1,1501):
        w.writerow([i,f"{random.choice(FIRST)} {random.choice(LAST)}",
                    random.choices(CITIES,CITY_W)[0],
                    (start-timedelta(days=random.randint(0,400))).isoformat()])

with open("data/menu_items.csv","w",newline="") as f:
    w=csv.writer(f); w.writerow(["item_id","item_name","category","price"])
    for i,(n,c,p) in enumerate(MENU,1): w.writerow([i,n,c,p])

# repeat customers are weighted heavier (loyal base)
cust_w = [random.lognormvariate(0, 0.9) for _ in range(1500)]
def day_weight(d):
    t = (d - start).days / days
    w = 1 + 0.6 * t                       # growth trend
    if d.weekday() >= 4: w *= 1.6        # Fri-Sun busier
    if d.month in (10, 11, 12): w *= 1.15
    if d.month == 2: w *= 0.9
    return w
DAYS = [start + timedelta(days=i) for i in range(days)]
DAY_W = [day_weight(d) for d in DAYS]
orders, items = [], []
oi = 1
for oid in range(1,12501):
    # steady growth through the year, busier weekends, festive bump in Oct-Dec
    d = random.choices(DAYS, DAY_W)[0]
    cid = random.choices(range(1,1501),cust_w)[0]
    orders.append([oid,cid,d.isoformat(),random.choices(HOURS,HOUR_W)[0],
                   d.strftime("%A"),random.choices(OTYPE,OTYPE_W)[0],random.choices(PAY,PAY_W)[0]])
    for it in random.sample(range(1,21),random.choices([1,2,3,4],[25,40,25,10])[0]):
        items.append([oi,oid,it,random.choices([1,2,3],[70,22,8])[0]]); oi+=1

with open("data/orders.csv","w",newline="") as f:
    w=csv.writer(f); w.writerow(["order_id","customer_id","order_date","order_hour","day_name","order_type","payment_method"]); w.writerows(orders)
with open("data/order_items.csv","w",newline="") as f:
    w=csv.writer(f); w.writerow(["order_item_id","order_id","item_id","quantity"]); w.writerows(items)
print(len(orders),"orders,",len(items),"order lines")
